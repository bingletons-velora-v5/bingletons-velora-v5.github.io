const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();
const db = getFirestore();

// Add/remove words here. The first requested slur is assembled so it isn't written normally in this source.
const BANNED_TERMS = [
  "n" + "igger", "n" + "iggers",
  "chink", "spic", "kike", "wetback", "coon", "tranny",
  "fuck", "fucker", "fucking", "shit", "bitch", "cunt", "whore", "slut"
];

const normalize = (value) => String(value || "")
  .normalize("NFKC")
  .toLowerCase()
  .replace(/[0-9]/g, c => ({"0":"o","1":"i","3":"e","4":"a","5":"s","7":"t"}[c] || c))
  .replace(/[^a-z0-9]+/g, " ")
  .replace(/\s+/g, " ")
  .trim();

const containsBanned = (text) => {
  const n = normalize(text);
  return BANNED_TERMS.some(term => {
    const t = normalize(term);
    return n.split(" ").some(word => word === t || word.includes(t));
  });
};

exports.sendMessage = onCall({ region: "us-central1", enforceAppCheck: false }, async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "sign in first");

  const uid = request.auth.uid;
  const input = request.data || {};
  const name = String(input.name || "").replace(/[<>]/g, "").replace(/\s+/g, " ").trim().slice(0, 24);
  const text = String(input.text || "").trim().slice(0, 500);

  if (!name) throw new HttpsError("invalid-argument", "choose a name");
  if (!text) throw new HttpsError("invalid-argument", "empty message");

  const banRef = db.collection("bans").doc(uid);
  if ((await banRef.get()).exists) throw new HttpsError("permission-denied", "you are banned");

  if (containsBanned(text) || containsBanned(name)) {
    await banRef.set({ reason: "banned language", createdAt: FieldValue.serverTimestamp(), uid }, { merge: true });
    throw new HttpsError("permission-denied", "banned language");
  }

  // Basic global anti-spam: 1 message / 1.2 seconds and no more than 5 messages / 10 seconds.
  const rateRef = db.collection("rateLimits").doc(uid);
  const now = Date.now();
  const allowed = await db.runTransaction(async tx => {
    const snap = await tx.get(rateRef);
    const data = snap.exists ? snap.data() : {};
    const history = Array.isArray(data.history) ? data.history.filter(t => now - t < 10000) : [];
    if (history.length && now - history[history.length - 1] < 1200) return false;
    if (history.length >= 5) return false;
    history.push(now);
    tx.set(rateRef, { history }, { merge: true });
    return true;
  });

  if (!allowed) throw new HttpsError("resource-exhausted", "slow down");

  const messageRef = db.collection("messages").doc();
  await messageRef.set({
    uid,
    name,
    text,
    createdAt: FieldValue.serverTimestamp()
  });

  return { ok: true };
});
